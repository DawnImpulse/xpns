package org.sourcei.xpns.interfaces

/**
 * @info -
 *
 * @author - Saksham
 * @tnote Last Branch Update - master
 *
 * @tnote Created on 2018-09-05 by Saksham
 * @tnote Updates :
 */
interface Callback {
    fun call(any: Any)
}