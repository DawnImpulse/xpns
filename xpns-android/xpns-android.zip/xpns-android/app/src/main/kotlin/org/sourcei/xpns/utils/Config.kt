package org.sourcei.xpns.utils

/**
 * @info -
 *
 * @author - Saksham
 * @tnote Last Branch Update - master
 *
 * @tnote Created on 2018-08-13 by Saksham
 * @tnote Updates :
 */
object Config{
    var DbName = "Main"
}