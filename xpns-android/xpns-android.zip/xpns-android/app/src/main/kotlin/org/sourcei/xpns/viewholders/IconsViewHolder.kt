package org.sourcei.xpns.viewholders

import android.support.v7.widget.RecyclerView
import android.view.View
import kotlinx.android.synthetic.main.inflator_icons.view.*

/**
 * @info -
 *
 * @author - Saksham
 * @tnote Last Branch Update - master
 *
 * @tnote Created on 2018-09-04 by Saksham
 * @tnote Updates :
 */
class IconsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
    val icon = itemView.iconsI
}